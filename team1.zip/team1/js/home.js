/* const buttonTest = document.getElementById('buttonTest');

buttonTest.onclick = function () {
    window.location.href = './question1.html';
} */

$('#buttonTest').click(function (event) {
    event.preventDefault();
    window.location.href = './question1.html';
});