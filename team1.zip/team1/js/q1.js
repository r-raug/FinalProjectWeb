let sessionStorage = window.sessionStorage;

sessionStorage.setItem("currentQuestion", "1");