let cache = window.sessionStorage;

cache.clear();

console.log("Session storage cleared.");

console.log(cache);