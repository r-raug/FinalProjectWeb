const cache = window.sessionStorage;

const description = document.getElementById('result-description');

// Testing.
/* cache.setItem('answer1', '[1, 2, 3, 4]');
cache.setItem('answer2', '[4, 2, 3, 1]');
cache.setItem('answer3', '[1, 2, 3, 4]');
cache.setItem('answer4', '[1, 3, 2, 4]');
cache.setItem('answer5', '[1, 2, 3, 4]');
cache.setItem('answer6', '[1, 2, 3, 4]');
cache.setItem('answer7', '[1, 2, 3, 4]');
cache.setItem('answer8', '[1, 2, 3, 4]');
cache.setItem('answer9', '[1, 2, 3, 4]');
cache.setItem('answer10', '[1, 2, 3, 4]');
cache.setItem('answer11', '[1, 2, 3, 4]'); */

// Testing.
/* cache.setItem('answer1', '[2, 3, 4, 1]');
cache.setItem('answer2', '[2, 1, 4, 3]');
cache.setItem('answer3', '[3, 1, 2, 4]');
cache.setItem('answer4', '[1, 4, 3, 2]');
cache.setItem('answer5', '[3, 2, 1, 4]');
cache.setItem('answer6', '[4, 3, 2, 1]');
cache.setItem('answer7', '[2, 1, 4, 3]');
cache.setItem('answer8', '[1, 4, 3, 2]');
cache.setItem('answer9', '[4, 2, 1, 3]');
cache.setItem('answer10', '[3, 1, 2, 4]');
cache.setItem('answer11', '[4, 1, 3, 2]'); */

let allAnswerValid = true;

const colors = {
    "0": 'Orange',
    "1": 'Green',
    "2": 'Blue',
    "3": 'Gold',
};

const answersArray = [];

// Only storing the answer arrays into answersArray using for loop.
for (let i = 1; i <= 11; i++) {

    // Storing the 'answer+i' object value into answerArray

    if (!(`answer${i}` in cache)) {
        console.log("Please enter all question answer.");
        allAnswerValid = false;
    }

    // A common use of JSON is to exchange data to/from a web server. When receiving data from a web server, the data is always a string. Parse the data with JSON.parse(), and the data becomes a JavaScript object.
    // The JSON.parse() static method parses a JSON string, constructing the JavaScript value or object described by the string. An optional reviver function can be provided to perform a transformation on the resulting object before it is returned.
    // JSON.parse is a method in JavaScript used to parse a JSON string and convert it into a JavaScript object.
    const answerArray = JSON.parse(cache.getItem(`answer${i}`));

    // Adding a single answerArray into answersArray.
    answersArray.push(answerArray);
}

console.log(answersArray);

const totalScoreArray = [];

// const tableContainer = document.getElementById('result_contain');
const tableElement = document.querySelector('#result_table');
const tableContainer = document.createElement('tbody'); // Create a new tbody element

// The insertRow() method creates an empty <tr> element and adds it to a table. The insertRow() method inserts the new row(s) at the specified index in the table.
// The insertCell() method inserts a cell into the current row.

function loadTable() {

    if (allAnswerValid === false) {
        $('#errorMessage').css('display', 'block');
        $('#errorMessage').text('Please select all option.');
        return;
    }

    // let tbodyContain = '';

    for (let row = 0; row < 11; row++) {
        // tbodyContain += '<tr> <td>' + (row + 1) + '</td>';
        const tableRow = tableContainer.insertRow();

        tableRow.insertCell().textContent = `${row + 1}`;

        for (let column = 0; column < 4; column++) {
            // tbodyContain += `<td> ${answersArray[row][column]} </td>`
            tableRow.insertCell().textContent = `${answersArray[row][column]}`;
        }
        // tbodyContain += '</tr>';
    }

    // tbodyContain += '<tr><td>Total:</td>';
    let totalRow = tableContainer.insertRow();
    totalRow.insertCell().textContent = `Total:`;

    for (let col = 0; col < 4; col++) {

        let columnSum = calculateColumnScore(col);

        totalScoreArray.push(columnSum);

        // Displaying the total of the column.
        // tbodyContain += `<td>${columnSum}</td>`;
        totalRow.insertCell().innerHTML = `<strong>${columnSum}</strong>`;
    }

    // tbodyContain += '</tr><tr><td>Rank</td>';
    let rankRow = tableContainer.insertRow();

    rankRow.insertCell().textContent = `Rank:`;

    const rankScore = highestScore();

    rankScore.forEach(function (value) {
        // tbodyContain += `<td>${value}</td>`;
        rankRow.insertCell().innerHTML = `<strong>${value}</strong>`;
    });

    // tbodyContain += '</tr>';
    // tableContainer.innerHTML = tbodyContain;

    tableElement.appendChild(tableContainer);
    console.log(tableElement.children);

    const scoreColor = {
        first: [],
        second: [],
    }

    console.log(rankScore);

    rankScore.forEach(function (value, index) {
        // console.log(`Value = ${value}. Index = ${index}. Color = ${colors[index]}`);
        if (value == '1st') {
            scoreColor.first.push(colors[index]);
        }
        else if (value == '2nd') {
            scoreColor.second.push(colors[index]);
        }
    })

    console.log(scoreColor);

    $('#firstRank').html(`First color : ${scoreColor.first.join(', ')}`).css('font-weight', 'bold');
    $('#secondRank').html(`Second color : ${scoreColor.second.join(', ')}`).css('font-weight', 'bold');
}

function calculateColumnScore(col) {

    // Sum the row value and keeping the column constant.
    let sum = 0;

    for (let row = 0; row < 11; row++) {

        // Adding the row elements for one constant column.
        sum += answersArray[row][col];
    }

    console.log(`Sum for column: ${col}`, sum);
    return sum;
}

function highestScore() {

    // debugger;
    // Copying the value of totalScoreArray the into copyArray.
    let copyArray = [...totalScoreArray];

    // Sorting the array into descending order.
    copyArray.sort().reverse();

    // Creating the suffix object.
    const suffix = {
        "1": "st",
        "2": "nd",
        "3": "rd",
        "4": "th",
    }

    // Storing the key as rank and value as the score which score that rank.
    const positionObject = {};

    let count = 1;
    copyArray.forEach(function (value) {

        // If the key is not equal to value then add property with value =${count}${suffix[count++]};
        // if (!positionObject[value]) {
        if (!(value in positionObject)) {
            positionObject[value] = `${count}${suffix[count++]}`;
        }
    });

    console.log("Position with ranking", positionObject);

    // Find the corresponding position of each score using map and return the new array.
    const positionArray = totalScoreArray.map(function (value) {
        return positionObject[value];
    });

    console.log(positionArray);

    return positionArray;
}

window.onload = loadTable;